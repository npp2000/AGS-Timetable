import os
from bs4 import BeautifulSoup

# Path to your FET timetable output folder
TIMETABLE_FOLDER = "C:\\FET\\AGS\\timetables\\Primary School-12"  # Change to your actual folder path

def process_html_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            soup = BeautifulSoup(f, "html.parser")

        # Find all tables in the file
        for table in soup.find_all("table"):
            # Get column headers
            headers = [th.get_text(strip=True) for th in table.find_all("th")]

            # Process each row
            for row in table.find_all("tr"):
                cells = row.find_all("td")
                for idx, cell in enumerate(cells):
                    if idx < len(headers):
                        cell["data-label"] = headers[idx]

        # Save updated HTML
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(str(soup))

        print(f"Processed: {file_path}")

    except Exception as e:
        print(f"Error processing {file_path}: {e}")

def main():
    if not os.path.isdir(TIMETABLE_FOLDER):
        print(f"Folder not found: {TIMETABLE_FOLDER}")
        return

    for filename in os.listdir(TIMETABLE_FOLDER):
        if filename.endswith(".html"):
            process_html_file(os.path.join(TIMETABLE_FOLDER, filename))

if __name__ == "__main__":
    main()
