import os

# Path to folder containing FET timetable HTML files
TIMETABLE_FOLDER = "C:\\FET\\AGS\\timetables\\Primary School-12"  # Change to your folder path
CSS_FILENAME = "custom.css"

# The link tag we want to insert
css_link_tag = f'<link rel="stylesheet" type="text/css" href="{CSS_FILENAME}">\n'

def add_css_to_html_files(folder_path):
    if not os.path.exists(folder_path):
        print(f"Error: Folder '{folder_path}' does not exist.")
        return

    html_files = [f for f in os.listdir(folder_path) if f.lower().endswith(".html")]

    if not html_files:
        print("No HTML files found in the folder.")
        return

    for filename in html_files:
        file_path = os.path.join(folder_path, filename)

        try:
            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read()

            # Only insert if not already present
            if css_link_tag.strip() not in content:
                if "<head>" in content:
                    content = content.replace("<head>", "<head>\n" + css_link_tag)
                    with open(file_path, "w", encoding="utf-8") as file:
                        file.write(content)
                    print(f"✅ Added CSS link to: {filename}")
                else:
                    print(f"⚠ Skipped {filename} — no <head> tag found.")
            else:
                print(f"ℹ CSS link already present in: {filename}")

        except Exception as e:
            print(f"❌ Error processing {filename}: {e}")

if __name__ == "__main__":
    add_css_to_html_files(TIMETABLE_FOLDER)
